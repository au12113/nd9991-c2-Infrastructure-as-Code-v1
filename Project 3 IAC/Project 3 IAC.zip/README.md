### ND9991 - C2- Infrastructure as Code - Deploy a high-availability web app using CloudFormation
I separate to two templates:

#### servers.yml

#### network.yml
servers template used in servers template